from django.contrib import admin
from .models import Beer, BeerReview

admin.site.register(Beer)
admin.site.register(BeerReview)

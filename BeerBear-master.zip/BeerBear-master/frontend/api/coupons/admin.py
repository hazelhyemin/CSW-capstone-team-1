from django.contrib import admin
from .models import Coupon

admin.site.register(Coupon)
from django.apps import AppConfig


class BeershopsConfig(AppConfig):
    name = 'beershops'

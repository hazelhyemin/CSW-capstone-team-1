from django.contrib import admin
from .models import BeerShop, BeerShopReview, Stamp
admin.site.register(BeerShop)
admin.site.register(BeerShopReview)
admin.site.register(Stamp)
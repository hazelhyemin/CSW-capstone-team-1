export default ShopReview = [
    user1 = {
        num : 1,
        user_id : "Mina",
        content : "Such a wonderful brewery!!",
        created_at : "18/12/07 4:30pm",
        parent : null
    },
    user2 = {
        num : 2,
        user_id : "Dongsu",
        content : "Definitely worth to visit!!",
        created_at : "18/12/02 11:00pm",
        parent : null
    },
    user3 = {
        num : 3,
        user_id : "Leon",
        content : "Thank you for the greate dishes!",
        created_at : "18/11/10 9:30pm",
        parent : null
    }
]
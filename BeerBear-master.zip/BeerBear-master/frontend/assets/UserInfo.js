export default User = [
    user1 = {
        id : "test",
        password: "123456",
    },
    user2 = {
        id: "test2",
        password: "123456",
    },
    user3 = {
        id: "test3",
        password: "123456",
    },
    user4 = {
        id: "test4",
        password: "123456",
    },
    user5 = {
        id: "test5",
        password: "123456",
    },
    user6 = {
        id: "test6",
        password: "123456",
    }
]
export default Chatroom = [
    user1 = {
        sender_id : "James",
        content : "Hello! I have a question.",
        created_at : "3:50pm"

    },
    user2 = {
        sender_id : "Jolly",
        content : "Could you do me a favor?",
        created_at : "1:30pm"
    },
    user3 = {
        sender_id : "Mina",
        content : "Please send me back!",
        created_at : "1:10pm"
    },
    user4 = {
        sender_id : "Summa",
        content : "Reply plzzzzz",
        created_at : "12:50pm"
    },
    user5 = {
        sender_id : "Martin",
        content : "문의합니다.",
        created_at : "12:10pm"
    }
]
/*
export const me = {
  "gender": "male",
  "name": {
    "title": "mr",
    "first": "lance",
    "last": "thomas"
  },
  "location": {
    "street": "6942 first street",
    "city": "elk grove",
    "state": "new hampshire",
    "postcode": 30411
  },
  "email": "lance.thomas@example.com",
  "login": {
    "username": "organicmouse687",
    "password": "frodo1",
    "salt": "0cSpyp70",
    "md5": "bf758d9c79ef3c8a2c3fd900fb0c3148",
    "sha1": "4f28fcd2d5e5ae5e0ff55b7528841e350cabf9fb",
    "sha256": "1d44ef3ad01dafe929c56021498d8a6d89b2c438bd3f6a07de777ed35b98b5e1"
  },
  "dob": "1969-12-14 07:28:16",
  "registered": "2010-08-09 13:37:38",
  "phone": "(589)-070-0928",
  "cell": "(110)-065-6280",
  "id": {
    "name": "SSN",
    "value": "408-64-0336"
  },
  "picture": {
    "large": "https://randomuser.me/api/portraits/men/2.jpg",
    "medium": "https://randomuser.me/api/portraits/med/men/2.jpg",
    "thumbnail": "https://randomuser.me/api/portraits/thumb/men/2.jpg"
  },
  "nat": "US"
};
*/
//export const users = [
  export default users = [
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "세강준",
      "last": ""
    },
    "location": {
      "street": "3649 dieppe ave",
      "city": "maitland",
      "state": "nunavut",
      "postcode": 58699
    },
    "email": "jacob.wilson@example.com",
    "login": {
      "username": "smallmouse862",
      "password": "christin",
      "salt": "2syKiC3G",
      "md5": "38abd66466233cb15cbe32bc9bfe5159",
      "sha1": "9aa0e9f0cf924bfe649d20eda1defd1dcb6ac20b",
      "sha256": "3ac7bc516b195eab9f6c91ebc093a0ac35ef35cdb292cca0beaef22feb835226"
    },
    "dob": "1979-12-06 16:10:13",
    "registered": "2008-12-25 08:51:40",
    "phone": "132-274-9669",
    "cell": "889-621-4075",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "http://spnimage.edaily.co.kr/images/Photo/files/NP/S/2018/05/PS18053100138.jpg",
      "medium": "http://spnimage.edaily.co.kr/images/Photo/files/NP/S/2018/05/PS18053100138.jpg",
      "thumbnail": "https://randomuser.me/api/portraits/thumb/men/2.jpg"
    },
    "nat": "CA"
  },
  {
    "gender": "male",
    "name": {
      "title": "mr",
      "first": "박마례",
      "last": ""
    },
    "location": {
      "street": "3875 fatih sultan mehmet cd",
      "city": "elazığ",
      "state": "erzincan",
      "postcode": 44000
    },
    "email": "barış.adal@example.com",
    "login": {
      "username": "goldenduck344",
      "password": "dogwood",
      "salt": "s3YLIy3o",
      "md5": "0475fbb9357434458f8b5990b6d8bf38",
      "sha1": "1d1d086f2b255eec0fb905ec171d2552ed5352c6",
      "sha256": "472543aba428f162187dae5cf4d8e851410e7b6a5ee66511c277c3266db87684"
    },
    "dob": "1980-05-31 10:31:12",
    "registered": "2013-06-10 12:48:40",
    "phone": "(483)-824-9134",
    "cell": "(255)-294-7516",
    "id": {
      "name": "",
      "value": null
    },
    "picture": {
      "large": "http://file.mk.co.kr/meet/neds/2017/03/image_readtop_2017_208557_14906633682825856.jpg",
      "medium": "http://file.mk.co.kr/meet/neds/2017/03/image_readtop_2017_208557_14906633682825856.jpg",
      "thumbnail": "http://file.mk.co.kr/meet/neds/2017/03/image_readtop_2017_208557_14906633682825856.jpg",
    },
    "nat": "US"
  },
  {
    "gender": "female",
    "name": {
      "title": "miss",
      "first": "무무",
      "last": ""
    },
    "location": {
      "street": "7057 nowlin rd",
      "city": "salem",
      "state": "south dakota",
      "postcode": 47964
    },
    "email": "lillie.fox@example.com",
    "login": {
      "username": "browngorilla270",
      "password": "carnage",
      "salt": "9wvhzjAh",
      "md5": "34d6d4b7b4622e7f2b62009c7e6a8c2b",
      "sha1": "18399e977056770b332ff7f9e6d3bab02a141e8d",
      "sha256": "96ad392016f86432a04a8f4915cda7b5631e6aefcdfee5624f3af00ca7836375"
    },
    "dob": "1970-11-05 12:45:41",
    "registered": "2012-03-02 19:36:43",
    "phone": "(115)-485-1830",
    "cell": "(611)-766-4831",
    "id": {
      "name": "SSN",
      "value": "527-24-8023"
    },
    "picture": {
      "large": "https://i.pinimg.com/originals/88/84/f2/8884f2462c4bc32a3e512645e23372b7.jpg",
      "medium": "https://i.pinimg.com/originals/88/84/f2/8884f2462c4bc32a3e512645e23372b7.jpg",
      "thumbnail": "https://i.pinimg.com/originals/88/84/f2/8884f2462c4bc32a3e512645e23372b7.jpg"
    },
    "nat": "US"
  }
];

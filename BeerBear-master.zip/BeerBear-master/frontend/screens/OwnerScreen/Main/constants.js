const mainColor = '#01C89E'

export default mainColor

const API_URL = "http://79b894a3.ngrok.io";
export default {
    API_URL
}